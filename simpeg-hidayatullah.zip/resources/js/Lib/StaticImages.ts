import HarunaPP from "@/Assets/Images/29ac0ba81a9bfc14fb96ffe82f11adb2.webp";
import PPHBackground from "@/Assets/Images/ponpes-hidayatullah-landing.webp";
import PPHLogo from "@/Assets/Images/logo-pph.webp";

export {
    HarunaPP,
    PPHBackground,
    PPHLogo
};
