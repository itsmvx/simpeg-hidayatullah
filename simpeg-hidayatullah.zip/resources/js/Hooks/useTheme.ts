import { useContext } from "react";
import { ThemeContext, ThemeContextType } from "@/Contexts/ThemeContext";

export const useTheme = () => {
    const { theme, setTheme } = useContext(ThemeContext) as ThemeContextType;
    return { theme, setTheme };
}
