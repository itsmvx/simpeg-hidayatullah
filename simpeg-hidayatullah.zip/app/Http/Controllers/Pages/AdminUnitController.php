<?php

namespace App\Http\Controllers\Pages;

use App\Http\Controllers\Controller;
use App\Models\Unit;
use Illuminate\Http\Request;
use Inertia\Inertia;

class AdminUnitController extends Controller
{
    public function loginPage()
    {
        return Inertia::render('Admin/AdminLoginPage', [
            'units' => Unit::select('id', 'nama', 'keterangan')->get()
        ]);
    }
    public function dashboardPage($unitId)
    {
        dd($unitId);
    }
}
